#-- minimize scalar function for decap optimization by scipy's dual annealing method
#
#-- using interposer+chiplet example interposer+duo
#
#-- with block core1's isrc and its nodes decaps (fixed location, optimizing value)
#-- 1) use relative objective/cost instead of real VDI_total only;
#-- 2) consider both core1's total vdi and total decap value in cost objective function;
#-- 3) part of core1's decaps are pre-defined (fixed), only some nodes' decaps are optimizable

import os
import sys
import numpy as np
from scipy import optimize
from scipy.optimize import minimize
from scipy.optimize import brute


if len(sys.argv) != 1:
    print("Usage: python3 opt-anneal-3.py")
    sys.exit(1)

#-- global vars
func_eval_no = 0   # obj function evaluation count
vdi_max = 0.0
vdi_min = 100.0
dcap_max = 0.0
dcap_min = 100.0

#-- read csv result
def ReadCsvResult(filename):
    array = np.genfromtxt(filename, skip_header=1, skip_footer=1)
    return array

def objective(x):
    global func_eval_no
    global min_dcap, max_dcap
    global vdi_max, vdi_min
    global dcap_max, dcap_min

    func_eval_no += 1

    f = open("duo_core1_vdd_decap_dcap10.param", 'w')
    j = 0
    cellcount = len(x)
    for c in x:
        f.write('.param dcap_%d_val=%e\n' %  (j, x[j]))
        j += 1
    f.close()

    dcap_total = np.sum(x)

#-- run ngspice and convert raw to csv format
    os.system("ngspice -b int1_tr_core1_dcap10.sp -r t1.raw > /dev/null 2> /dev/null")
#-- we only account core1 block's VDI instead of whole die's VDI
    os.system("./bin/inttrvmapblk int1.conf t1.raw 1.2 0.12 duo_core1_vdd.decap 2>> t1.log")

#-- read vdi result
    vdi_array = ReadCsvResult("duo_vdd_1_vdi.csv")
    vdi = vdi_array[:,2]
    vdi_total = np.sum(vdi)
    print("vdi_total ", func_eval_no, vdi_total)
    #return vdi_total

    if vdi_total > vdi_max:
        vdi_max = vdi_total
    if vdi_total < vdi_min:
        vdi_min = vdi_total

    if dcap_total > dcap_max:
        dcap_max = dcap_total
    if dcap_total < dcap_min:
        dcap_min = dcap_total

    if (dcap_total < max_dcap):
        alpha = 0.0
    else:
        alpha = min(0.1+0.1*(dcap_total-min_dcap)/max_dcap, 0.9)

    if (dcap_min != dcap_max and vdi_max != vdi_min):
        cost1 = alpha*(dcap_total-dcap_min)/(dcap_max-dcap_min)
        cost2 = (1.0-alpha)*(vdi_total-vdi_min)/(vdi_max-vdi_min)
        cost = cost1 + cost2
    else:
        cost1 = alpha*(dcap_total-dcap_min)
        cost2 = (1.0-alpha)*(vdi_total-vdi_min)
        cost = cost1 + cost2 + 1.0

    print("cost ", func_eval_no, alpha, cost1, cost2, cost)
    return cost


def constraint1(x):
    totalc = 0.0
    j = 0
    for c in x:
        totalc += x[j]
        j += 1
    return 1.0e-8 - totalc


#-- here is the parameters need to be assigned
#-- decap count to be optimized
min_dcap = 1.0e-9     # decap leakage cost offset
max_dcap = 10.0e-9    # decap leakage cost threshold
decapno = 10     # decap # to be optimized
maxi = 200        # 10 annealing iteration limit, default is 1000
init_cap = 1.0e-15

#-- initial values
#cap0 = np.array([1.0e-15, 1.0e-15, 1.0e-15, 1.0e-15, 1.0e-15])
#cap0 = np.full(5, 1.0e-15)
#cap0 = np.full(5, 1.0e-11)
cap0 = np.array([init_cap]*decapno)

#-- bounds
lb = [1.0e-15]*decapno
ub = [2.1e-9]*decapno
bounds = list(zip(lb, ub))

#rranges = (slice(0, 2e-9, 0.2e-9))*decapno

#-- constraint
con1 = {'type': 'ineq', 'fun': constraint1}
cons = [con1]


#-- this is a good first step
#sol = minimize(objective, cap0, method='SLSQP', bounds=bnds, constraints=cons, tol=1e-15)
os.system("rm -rf t1.log")
#minsol = brute(objective, rranges, finish=optimize.fmin, full_output=True, disp=True)
minsol = brute(objective, bounds, finish=optimize.fmin, Ns=2, full_output=True, disp=True)

print(minsol)
