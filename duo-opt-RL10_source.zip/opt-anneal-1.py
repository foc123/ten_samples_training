#-- minimize scalar function for decap optimization by scipy's dual annealing method
#-- using interposer+chiplet example interposer+duo
#-- with block core1's isrc and its nodes decaps (fixed location, optimizing value)
#-- objective: core1's vdi only

import os
import sys
import numpy as np
from scipy.optimize import dual_annealing


if len(sys.argv) != 1:
    print("Usage: python3 opt-anneal.py")
    sys.exit(1)

#-- obj function evaluation count
func_eval_no = 0


#-- read csv result
def ReadCsvResult(filename):
    array = np.genfromtxt(filename, skip_header=1, skip_footer=1)
    return array

def objective(x):
    global func_eval_no

    func_eval_no += 1

    f = open("duo_core1_vdd_decap.param", 'w')
    j = 0
    cellcount = len(x)
    for c in x:
        f.write('.param dcap_%d_val=%e\n' %  (j, x[j]))
        j += 1
    f.close()

#-- run ngspice and convert raw to csv format
    os.system("ngspice -b int1_tr_core1.sp -r t1.raw > /dev/null 2> /dev/null")
#-- we only account core1 block's VDI instead of whole die's VDI
    os.system("./bin/inttrvmapblk int1.conf t1.raw 1.2 0.12 duo_core1_vdd.decap 2>> t1.log")

#-- read vdi result
    vdi_array = ReadCsvResult("duo_vdd_1_vdi.csv")
    vdi = vdi_array[:,2]
    vdi_total = np.sum(vdi)
    print("vdi_total ", func_eval_no, vdi_total)
    return vdi_total


def constraint1(x):
    totalc = 0.0
    j = 0
    for c in x:
        totalc += x[j]
        j += 1
    return 1.0e-8 - totalc


#-- here is the parameters need to be assigned
#-- decap count to be optimized
decapno = 25
maxi = 1000    #-- should be 1000
init_cap = 1.0e-15

#-- initial values
#cap0 = np.array([1.0e-15, 1.0e-15, 1.0e-15, 1.0e-15, 1.0e-15])
#cap0 = np.full(5, 1.0e-15)
#cap0 = np.full(5, 1.0e-11)
cap0 = np.array([init_cap]*decapno)

#-- bounds
lb = [0.0]*decapno
ub = [1.2e-9]*decapno
bounds = list(zip(lb, ub))

#-- constraint
con1 = {'type': 'ineq', 'fun': constraint1}
cons = [con1]


#-- this is a good first step
#sol = minimize(objective, cap0, method='SLSQP', bounds=bnds, constraints=cons, tol=1e-15)
os.system("rm -rf t1.log")

minsol = dual_annealing(objective, bounds, maxiter=maxi)

print(minsol)
